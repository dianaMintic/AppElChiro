package com.example.elchirostore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ResumenPedido extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumen_pedido);
    }
}